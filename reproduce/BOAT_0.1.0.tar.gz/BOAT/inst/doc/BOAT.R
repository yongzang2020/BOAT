## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(collapse = TRUE, comment = "#>")

## -----------------------------------------------------------------------------
library(BOAT)

## -----------------------------------------------------------------------------
design <- boat_design(K = 3, J = 3, arms = list(c(0, 1, 3), 0:3, c(0, 2, 3)), N = 150,
                      interim = c(0.5, 0.75), lambda = 0.70, delta_T = 0.05, delta_R = 0.05,
                      mcmc = list(iter = 1000, burn = 500))
design

## -----------------------------------------------------------------------------
bounds <- boat_boundary(design)
bounds

## -----------------------------------------------------------------------------
truth <- boat_scenario(pR = rbind(c(0.50, 0.30, NA, 0.70),
                                  c(0.50, 0.70, 0.50, 0.30),
                                  c(0.30,   NA, 0.50, 0.30)),
                       piT = c(0.25, 0.35, 0.20, 0.15))
truth
trial <- boat_simulate_trial(design, truth, seed = 2031, keep_data = TRUE)
pat <- trial$pat
pdo <- trial$pdo
head(pat)
head(pdo)

## -----------------------------------------------------------------------------
data_at <- function(n) {
  keep <- ave(pat$id, pat$k, FUN = seq_along) <= n[pat$k]
  list(pat = pat[keep, ], pdo = pdo[pdo$id %in% pat$id[keep], ], n = tabulate(pat$k[keep], design$K))
}

## -----------------------------------------------------------------------------
boat_randomize(design, k = 1)$prob

## -----------------------------------------------------------------------------
d1 <- data_at(bounds$n[bounds$analysis == "Interim 1"])
fit1 <- boat_fit(design, d1$pat, d1$pdo, seed = 2031 + 1000)
fit1
dec1 <- boat_decide(design, fit1, n = d1$n)
dec1

## -----------------------------------------------------------------------------
rar1 <- boat_rar_model(design, d1$pat, d1$pdo, active = dec1$active)
i <- max(d1$pat$id) + 1
pat[pat$id == i, ]
pdo_mean <- with(pdo[pdo$id == i, ], tapply(YO, j, mean))
pdo_mean
boat_randomize(design, k = pat$k[pat$id == i], pdo_mean = pdo_mean, rar = rar1)$prob

## -----------------------------------------------------------------------------
d2 <- data_at(bounds$n[bounds$analysis == "Interim 2"])
fit2 <- boat_fit(design, d2$pat, d2$pdo, seed = 2031 + 2000)
dec2 <- boat_decide(design, fit2, n = d2$n, active = dec1$active)
dec2
rar2 <- boat_rar_model(design, d2$pat, d2$pdo, active = dec2$active)

## -----------------------------------------------------------------------------
d3 <- data_at(design$N)
fit3 <- boat_fit(design, d3$pat, d3$pdo, seed = 2031 + 3000)
boat_decide(design, fit3, n = d3$n, active = dec2$active, final = TRUE)

## -----------------------------------------------------------------------------
trial

## -----------------------------------------------------------------------------
fast <- boat_design(arms = list(c(0, 1, 3), 0:3, c(0, 2, 3)), N = 150, lambda = 0.70,
                    mcmc = list(iter = 300, burn = 150), rar_mcmc = list(iter = 200, burn = 100))
oc <- boat_get_oc(fast, truth, nsim = 2)
oc

## ----eval = FALSE-------------------------------------------------------------
# cal <- boat_calibrate(design, list(truth), lambda = seq(0.64, 0.76, by = 0.02),
#                       nsim = 1000, cores = 8)
# cal

